# ====== Login data ======
username = "mohammed.khaled@naseej.com"
password = "Medad@123"

# ======== Add New Institutions ===========
Institution_Code = "KH-01"
Institution_Name = "MKhaled"
Website = "http://www.google.com"
Email = "test@test.com"
Location = "Tanta"
MOE_Number = "15"

# =============== Add New Campuses ========================
Campus_name = "khaled"
Campus_code = "12345"
Campus_location = "data"

# =============== Add New Colleges ========================
College_Name = "mokhaled"
College_Code = "2121"